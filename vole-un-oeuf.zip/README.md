# 🥚 Vole un Œuf — Édition Brainrot 3D

Jeu web 3D (Three.js) jouable dans le navigateur, sur PC et sur mobile.

Vole les œufs gardés par des poules, ramène-les à ta base et fais-les éclore en brainrots qui rapportent de l'argent.

![Léo, Amaury et leurs œufs](leo-amaury.png)

## Gameplay
- **5 zones** : Prairie, Désert, Banquise, Volcan, Cosmos — chaque zone demande une vitesse minimale.
- **6 raretés d'œufs** : Commun, Rare, Épique, Légendaire, Mythique, SECRET (+ mutations Or, Diamant, Arc-en-ciel).
- **Tapis de course** unique, améliorable (12 niveaux).
- **Base agrandissable** : +2 places par agrandissement, jusqu'à 4 étages reliés par un ascenseur.
- **Objets à usage limité** débloqués par les étages : banane, turbo, cage, couveuse, bouclier, aimant.
- **Index** de tous les œufs et brainrots avec les chances par zone.
- Vue **1ère personne** par défaut (touche V / bouton pour la 3ème personne).

## Contrôles
| PC | Mobile |
|---|---|
| ZQSD / WASD pour bouger | Glisser à gauche pour bouger |
| Clic-glisser pour regarder | Glisser à droite pour regarder |
| E / Espace pour agir | Bouton ✋ |
| 1-6 pour les objets | Icônes en bas |
| V pour changer de vue | Bouton 🎥 |

## Lancer le jeu
Ouvrir `index.html` dans un navigateur (connexion internet nécessaire pour charger Three.js), ou activer GitHub Pages sur la branche `main`.

La progression est sauvegardée dans le navigateur (localStorage).
